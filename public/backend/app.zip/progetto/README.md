# hypermedia2019
query fatte:
per gli eventi artistici
  tutti gli eventi    /artisticEvent/     (get)

  tutti i tipi        /artisticEvent/types    (get)

  quelli di oggi      /artisticEvent/today    (get)

  per id              /artisticEvent/:id      (get)
      esempio   /artisticEvent/7

  per tipo            /artisticEvent/type/:type (get)
      esempio   /artisticEvent/type/opera

  per performer       /artisticEvent/performer/:id  (get)
      si passa l'id del performer e si ricevono gli eventi artistici in cui si è esibito

  stesso giorno       /artisticEvent/sameDay/:id    (get)
      si passa l'id di un evento restituisce gli eventi che ci sono lo stesso giorno tranne quello che ha l'id uguale a quello passato

  per seminario       /artisticEvent/seminar/:id  (get)
      esempio     /artisticEvent/seminar/5
      restituisce gli eventi artistici relativi al seminario con idseminar=5


per i seminari
  tutti               /seminar/     (get)

  oggi                /seminar/today    (get)

  per id              /seminar/:id      (get)
      esempio   /seminar/10

  per evento artistico  /seminar/artisticEvent/:id  (get)
      esempio   /seminar/artisticEvent/3
      restituisce i seminari che riguardano l'evento artisco con idevent=3


per gli utenti
  login               /user/login        (post)
      nel body viene inserito mail e password chiamati "mail" "pass"

  logout              /user/logout       (delete)

  signup              /user/signup       (post)
        nel body viene inserito mail, password e nome chiamati "mail" "password" "name"


per gli artisti
  tutti               /performer/    (get)

  per id              /performer/:id    (get)
      esempio   /performer/5

  per evento          /performer/artisticEvent/:id  (get)
      l'id passato nell'url è l'id dell'evento di cui si vogliono sapere gli artisti

NB. per i metodo qui sotto il server prende l'iduser dal cookie che viene passato automaticamente ad ogni query


per il carrello eventi artistici
    gli eventi di un utente   /reservationArtisticEvent/     (get)

    per inserire un seminario nel carrello  /reservationtArtisticEvent/   (post)
        nel body bisogna inserire l'id dell'evento artistico e va chiamato "id"

    per svuotare il carrello  /reservationArtisticEvent/     (delete)

    per cancellare un specifico seminario   /reservationArtisticEvent/:id (delete) !!!!!!!!!!!!!!!!!

    per controllare se è già presente   /reservationArtisticEvent/:id     (get)
        dove id è l'id dell'evento artistico

________________________________________________________________________________

per il carrello seminari
    i seminari di un utente   /reservationSeminar/           (get)

    per svuotare il carrello  /reservationSeminar/           (delete)

    per inserire un seminario nel carrello  /reservationtSeminar/   (post)
        nel body bisogna inserire l'id del seminario e va chiamato "id"

    per cancellare un specifico seminario   /reservationSeminar/:id (delete)  !!!!!!!!!!!!!!!!!!!!!!!!!!

    per controllare se è già presente   /reservationSeminar/:id     (get)
            dove id è l'id del seminario
